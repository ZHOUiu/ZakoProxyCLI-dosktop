import{a2 as r}from"./index-B8SIgUWo.js";var o=r();export{o as r};
