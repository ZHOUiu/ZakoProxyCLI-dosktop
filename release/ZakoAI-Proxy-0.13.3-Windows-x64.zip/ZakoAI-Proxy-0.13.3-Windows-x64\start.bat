@echo off
cd /d "%~dp0"
if exist "ZakoAI.Desktop.exe" (
  start "" "ZakoAI.Desktop.exe"
) else (
  start "" "zakoai-proxy.exe"
)
